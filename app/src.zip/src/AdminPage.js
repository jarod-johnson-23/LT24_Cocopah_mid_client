import "./AdminPage.css";
import Navbar from "./components/Navbar";

function AdminPage() {
  return (
    <div className="admin-content">
      <Navbar />
    </div>
  );
}

export default AdminPage;
